// src/components/navbar/Navbar.js

import React from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Import Link and useNavigate
import './navbar.css';

const Navbar = () => {
    const navigate = useNavigate();
    
    // Check for the authentication token in localStorage
    const isLoggedIn = !!localStorage.getItem('authToken');

    // Define the logout function
    const handleLogout = () => {
        // Remove the token from localStorage
        localStorage.removeItem('authToken');
        // Redirect to the login page
        navigate('/login');
    };

    return (
        <nav className="navbar">
            <Link to="/" className="navbar-logo">TP<span>MS</span></Link>
            
            <div className="navbar-links">
                <Link to="/" className="navbar-link">Home</Link>
                <Link to="/about" className="navbar-link">About</Link>
                
                {/* Conditionally render links based on login status */}
                {isLoggedIn ? (
                    // Links to show if the user IS logged in
                    <>
                        <Link to="/profile" className="navbar-link">Profile</Link>
                        {/* This is a button to handle the logout action */}
                        <button onClick={handleLogout} className="navbar-link logout-btn">Logout</button>
                    </>
                ) : (
                    // Links to show if the user IS NOT logged in
                    <>
                        <Link to="/login" className="navbar-link">Login</Link>
                        <Link to="/register" className="navbar-link">Register</Link>
                    </>
                )}
            </div>
        </nav>
    );
};

export default Navbar;