// src/pages/Register.js

import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import RegisterStep2 from '../components/register/RegisterStep2';
import '../components/register/registerSteps.css';

const API_URL = 'http://127.0.0.1:8000/api';

const Register = () => {
    const [step, setStep] = useState(1);
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        gender: '',
        role: '',
        phone_number: '',
        address: '',
        dob: ''
    });

    const nextStep = () => setStep(step + 1);
    const prevStep = () => setStep(step - 1);

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const sendOTP = async () => {
        if (formData.password !== formData.confirmPassword) {
            setErrors({ confirmPassword: ["Passwords do not match."] });
            return;
        }
        setErrors({});
        try {
            const payload = {
                username: formData.username,
                email: formData.email,
                password: formData.password,
                first_name: formData.firstName,
                last_name: formData.lastName
            };
            const response = await axios.post(`${API_URL}/register/`, payload);
            console.log(response.data);
            nextStep();
        } catch (error) {
            if (error.response && error.response.data) {
                setErrors(error.response.data);
            } else {
                console.error('Registration failed:', error.message);
                alert('An unexpected error occurred. Please try again.');
            }
        }
    };

// src/pages/Register.js

const verifyOTP = async (otp) => {
    try {
        const payload = { email: formData.email, otp: otp };
        const response = await axios.post(`${API_URL}/verify-otp/`, payload);

        // --- THIS IS THE FIX ---
        // Check for the token from the backend and save it to localStorage
        if (response.data.token) {
            localStorage.setItem('authToken', response.data.token);
            nextStep(); // Move to profile details step
        }
    } catch (error) {
        alert('Invalid or expired OTP.');
        console.error('OTP verification failed:', error.response ? error.response.data : error.message);
    }
};

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('authToken');
        if (!token) {
            alert('Authentication error. Please try again.');
            return;
        }

        try {
            const profileData = {
                gender: formData.gender,
                role: formData.role,
                phone_number: formData.phone_number,
                address: formData.address,
                dob: formData.dob
            };

            const response = await axios.patch(`${API_URL}/complete-profile/`, profileData, {
                headers: { 'Authorization': `Token ${token}` }
            });

            console.log('Profile completed:', response.data);
            alert('Registration complete! Please log in to continue.');
            
            // ---> THIS IS THE FIX <---
            // 1. Remove the temporary token from the browser
            localStorage.removeItem('authToken');
            
            // 2. Redirect the user to the login page
            navigate('/login');

        } catch (error) {
            alert('Failed to complete your profile.');
            console.error('Profile completion failed:', error.response ? error.response.data : error.message);
        }
    };

    return (
        <div className="register-page">
            <section className="register-hero">
                <h1>Showcase Your Talent</h1>
                <p>Connect with the best opportunities and grow your career with a community that values your skills and creativity.</p>
            </section>
            <div className="register-form-container">
                <form className="register-form" onSubmit={handleSubmit}>
                    <div className="progress-steps">
                        {/* You can add your progress bar JSX here */}
                    </div>

                    {step === 1 && (
                        <div className="step-content">
                            <h2>Create Your Account</h2>
                            <div className="form-group">
                                <input type="text" name="firstName" placeholder="First Name" value={formData.firstName} onChange={handleChange} required />
                                <input type="text" name="lastName" placeholder="Last Name" value={formData.lastName} onChange={handleChange} required />
                            </div>
                            <div className="form-group">
                                <input type="text" name="username" placeholder="Username" value={formData.username} onChange={handleChange} required />
                                {errors.username && <p className="error-text">{errors.username[0]}</p>}
                            </div>
                            <div className="form-group">
                                <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
                                {errors.email && <p className="error-text">{errors.email[0]}</p>}
                            </div>
                            <div className="form-group">
                                <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
                            </div>
                            <div className="form-group">
                                <input type="password" name="confirmPassword" placeholder="Confirm Password" value={formData.confirmPassword} onChange={handleChange} required />
                                {errors.confirmPassword && <p className="error-text">{errors.confirmPassword[0]}</p>}
                            </div>
                            <button type="button" onClick={sendOTP} className="btn-primary">Send OTP</button>
                        </div>
                    )}

                    {step === 2 && (
                        <RegisterStep2
                            email={formData.email}
                            prevStep={prevStep}
                            verifyOTP={verifyOTP}
                        />
                    )}

                    {step === 3 && (
                        <div className="step-content">
                            <h2>Complete Your Profile</h2>
                            <div className="form-group">
                                <select name="gender" value={formData.gender} onChange={handleChange} required>
                                    <option value="">Select Gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                    <option value="other">Other</option>
                                </select>
                                <select name="role" value={formData.role} onChange={handleChange} required>
                                    <option value="">Select Role</option>
                                    <option value="job_seeker">Job Seeker</option>
                                    <option value="recruiter">Recruiter</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <input type="tel" name="phone_number" placeholder="Phone Number" value={formData.phone_number} onChange={handleChange} required />
                            </div>
                            <div className="form-group">
                                <input type="text" name="address" placeholder="Address" value={formData.address} onChange={handleChange} required />
                            </div>
                            <div className="form-group">
                                <label>Date of Birth</label>
                                <input type="date" name="dob" value={formData.dob} onChange={handleChange} required />
                            </div>
                            <div className="form-group button-group">
                                <button type="button" onClick={prevStep} className="btn-secondary">Back</button>
                                <button type="submit" className="btn-primary">Register</button>
                            </div>
                        </div>
                    )}
                </form>
            </div>
        </div>
    );
};

export default Register;