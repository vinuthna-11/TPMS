// src/components/PrivateRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';

const PrivateRoute = ({ children }) => {
    const isLoggedIn = !!localStorage.getItem('authToken');

    if (!isLoggedIn) {
        // If user is not logged in, redirect to login page
        return <Navigate to="/login" />;
    }

    // If user is logged in, show the requested page
    return children;
};

export default PrivateRoute;