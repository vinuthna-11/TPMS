// src/components/PublicRoute.js
import React from 'react';
import { Navigate } from 'react-router-dom';

const PublicRoute = ({ children }) => {
    const isLoggedIn = !!localStorage.getItem('authToken');

    if (isLoggedIn) {
        // If user is logged in, redirect to their profile
        return <Navigate to="/profile" />;
    }

    // If user is not logged in, show the requested page
    return children;
};

export default PublicRoute;