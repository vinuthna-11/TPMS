import React, { useState } from 'react';
import './registerSteps.css';

const RegisterStep1 = ({ formData, handleChange, nextStep }) => {
    const [errors, setErrors] = useState({});
    
    const validate = () => {
        const newErrors = {};
        let isValid = true;
        
        if (!formData.username) {
            newErrors.username = 'Username is required';
            isValid = false;
        } else if (formData.username.length < 4) {
            newErrors.username = 'Username must be at least 4 characters';
            isValid = false;
        }
        
        if (!formData.email) {
            newErrors.email = 'Email is required';
            isValid = false;
        } else if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
            newErrors.email = 'Please enter a valid email';
            isValid = false;
        }
        
        if (!formData.password) {
            newErrors.password = 'Password is required';
            isValid = false;
        } else if (formData.password.length < 8) {
            newErrors.password = 'Password must be at least 8 characters';
            isValid = false;
        }
        
        if (formData.password !== formData.confirmPassword) {
            newErrors.confirmPassword = 'Passwords do not match';
            isValid = false;
        }
        
        setErrors(newErrors);
        return isValid;
    };

    const handleNext = () => {
        if (validate()) {
            nextStep();
        }
    };

    return (
        <div className="step-content">
            <div className="step-header">
                <h2 className="form-title">Create Your Account</h2>
                <p className="form-subtitle">Join our community of talented professionals</p>
            </div>
            
            <div className="form-grid">
                <div className="form-group">
                    <label>Username</label>
                    <input
                        type="text"
                        name="username"
                        className={`form-control ${errors.username ? 'error' : ''}`}
                        value={formData.username}
                        onChange={handleChange}
                        placeholder="Enter your username"
                    />
                    {errors.username && <p className="error-message">{errors.username}</p>}
                </div>

                <div className="form-group">
                    <label>Email</label>
                    <input
                        type="email"
                        name="email"
                        className={`form-control ${errors.email ? 'error' : ''}`}
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Enter your email"
                    />
                    {errors.email && <p className="error-message">{errors.email}</p>}
                </div>

                <div className="form-group">
                    <label>Password</label>
                    <input
                        type="password"
                        name="password"
                        className={`form-control ${errors.password ? 'error' : ''}`}
                        value={formData.password}
                        onChange={handleChange}
                        placeholder="••••••••"
                    />
                    {errors.password && <p className="error-message">{errors.password}</p>}
                </div>

                <div className="form-group">
                    <label>Confirm Password</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        className={`form-control ${errors.confirmPassword ? 'error' : ''}`}
                        value={formData.confirmPassword}
                        onChange={handleChange}
                        placeholder="••••••••"
                    />
                    {errors.confirmPassword && (
                        <p className="error-message">{errors.confirmPassword}</p>
                    )}
                </div>
            </div>

            <div className="button-group">
                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleNext}
                >
                    Continue
                </button>
            </div>

            <div className="auth-footer">
                <p>Already have an account? <a href="/login">Sign in</a></p>
            </div>
        </div>
    );
};

export default RegisterStep1;