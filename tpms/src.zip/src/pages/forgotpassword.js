// src/pages/ForgotPassword.js

import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const API_URL = 'http://127.0.0.1:8000/api';

const ForgotPassword = () => {
    const [step, setStep] = useState(1); // 1 for email, 2 for OTP and new password
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [password, setPassword] = useState('');
    const [passwordConfirm, setPasswordConfirm] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleRequestOTP = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        try {
            await axios.post(`${API_URL}/password-reset/request/`, { email });
            setMessage('An OTP has been sent to your email. Please check your inbox.');
            setStep(2); // Move to the next step
        } catch (err) {
            setError('An error occurred. Please try again.');
        }
    };

    const handleConfirmReset = async (e) => {
        e.preventDefault();
        if (password !== passwordConfirm) {
            setError('Passwords do not match.');
            return;
        }
        setError('');
        setMessage('');

        try {
            const payload = { email, otp, password };
            await axios.post(`${API_URL}/password-reset/confirm/`, payload);
            setMessage('Your password has been reset successfully! Redirecting to login...');
            setTimeout(() => navigate('/login'), 3000); // Redirect to login after 3 seconds
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to reset password. The OTP may be invalid or expired.');
        }
    };

    return (
        <div className="wrapper">
            {step === 1 ? (
                <form className="loginpage" onSubmit={handleRequestOTP}>
                    <h2>Forgot Password</h2>
                    <p>Enter your email address to receive an OTP.</p>
                    <input
                        type="email"
                        placeholder="Your Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                    {message && <p className="success-text">{message}</p>}
                    {error && <p className="error-text">{error}</p>}
                    <button type="submit" className="login-btn">Send OTP</button>
                </form>
            ) : (
                <form className="loginpage" onSubmit={handleConfirmReset}>
                    <h2>Reset Your Password</h2>
                    <p>An OTP has been sent to {email}.</p>
                    <input
                        type="text"
                        placeholder="Enter OTP"
                        value={otp}
                        onChange={(e) => setOtp(e.target.value)}
                        required
                    />
                    <input
                        type="password"
                        placeholder="New Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                    <input
                        type="password"
                        placeholder="Confirm New Password"
                        value={passwordConfirm}
                        onChange={(e) => setPasswordConfirm(e.target.value)}
                        required
                    />
                    {message && <p className="success-text">{message}</p>}
                    {error && <p className="error-text">{error}</p>}
                    <button type="submit" className="login-btn">Reset Password</button>
                </form>
            )}
        </div>
    );
};

export default ForgotPassword;