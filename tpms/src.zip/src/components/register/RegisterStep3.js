import React from 'react';
import './registerSteps.css';

const RegisterStep3 = ({ formData, handleChange, handleSubmit, prevStep }) => {
    return (
        <div className="step-content">
            <div className="step-header">
                <h2 className="form-title">Complete Your Profile</h2>
                <p className="form-subtitle">Help us personalize your experience</p>
            </div>
            
            <div className="form-grid">
                <div className="form-group">
                    <label>Full Name</label>
                    <input
                        type="text"
                        name="fullName"
                        className="form-control"
                        value={formData.fullName}
                        onChange={handleChange}
                        placeholder="Your full name"
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Date of Birth</label>
                    <input
                        type="date"
                        name="dob"
                        className="form-control"
                        value={formData.dob}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Phone Number</label>
                    <input
                        type="tel"
                        name="phone"
                        className="form-control"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="+1 (___) ___-____"
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Skills (comma separated)</label>
                    <input
                        type="text"
                        name="skills"
                        className="form-control"
                        value={formData.skills}
                        onChange={handleChange}
                        placeholder="e.g., JavaScript, Design, Marketing"
                        required
                    />
                </div>
            </div>

            <div className="button-group">
                <button
                    type="button"
                    className="btn btn-outline"
                    onClick={prevStep}
                >
                    Back
                </button>
                <button
                    type="button"
                    className="btn btn-primary"
                    onClick={handleSubmit}
                >
                    Complete Registration
                </button>
            </div>
        </div>
    );
};

export default RegisterStep3;