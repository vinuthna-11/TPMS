import React, { useState, useEffect } from 'react';
import './registerSteps.css';

const RegisterStep2 = ({ email, prevStep, verifyOTP }) => {
    const [otp, setOtp] = useState('');
    const [timer, setTimer] = useState(60);
    const [error, setError] = useState('');

    useEffect(() => {
        const interval = setInterval(() => {
            setTimer(prev => (prev > 0 ? prev - 1 : 0));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    const handleOtpChange = (e) => {
        const value = e.target.value.replace(/\D/g, '');
        setOtp(value.slice(0, 6));
        setError('');
    };

    const handleSubmit = () => {
        if (otp.length !== 6) {
            setError('Please enter a 6-digit code');
            return;
        }
        verifyOTP(otp);
    };

    const resendOTP = () => {
        if (timer > 0) return;
        console.log('Resending OTP to:', email);
        setTimer(60);
        setOtp('');
        setError('');
    };

    return (
        <div className="step-content">
            <div className="step-header">
                <h2 className="form-title">Verify Your Email</h2>
                <p className="form-subtitle">We sent a 6-digit code to <strong>{email}</strong></p>
            </div>
            
            <div className="form-group">
                <label>Verification Code</label>
                <input
                    type="text"
                    value={otp}
                    onChange={handleOtpChange}
                    maxLength="6"
                    className={`form-control otp-input ${error ? 'error' : ''}`}
                    placeholder="••••••"
                    autoFocus
                />
                {error && <p className="error-message">{error}</p>}
            </div>

            <div className="otp-timer">
                {timer > 0 ? (
                    <span className="timer-text">Code expires in {timer}s</span>
                ) : (
                    <button 
                        type="button"
                        className="resend-link"
                        onClick={resendOTP}
                    >
                        Resend Code
                    </button>
                )}
            </div>

            <div className="button-group">
                <button
                    type="button"
                    className="btn btn-outline"
                    onClick={prevStep}
                >
                    Back
                </button>
                <button
                    type="button"
                    className="btn btn-primary"
                    disabled={otp.length !== 6}
                    onClick={handleSubmit}
                >
                    Verify
                </button>
            </div>
        </div>
    );
};

export default RegisterStep2;