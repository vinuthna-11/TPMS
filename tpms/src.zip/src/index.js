// src/index.js

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComponent from './components/navbar';
import Home from './pages/home';
import About from './pages/about';
import Login from './pages/login';
import Register from './pages/register';
import Profile from './pages/profile';

// ---> 1. IMPORT your new wrapper components
import PrivateRoute from './components/privateroute';
import PublicRoute from './components/publicroute';
import ForgotPassword from './pages/forgotpassword';

const App = () => (
  <>
    <NavbarComponent />
    <main>
      <Routes>
        {/* --- Public routes that anyone can see --- */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />

        {/* ---> 2. WRAP your public-only and private routes <--- */}

        {/* --- Routes only for LOGGED-OUT users --- */}
        <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
        <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />

        {/* --- Routes only for LOGGED-IN users --- */}
        <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />

        {/* --- Fallback route --- */}
        <Route path="*" element={<Navigate to="/" replace />} />
        <Route path="/forgot-password" element={<PublicRoute><ForgotPassword /></PublicRoute>} />
      </Routes>
    </main>
  </>
);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);