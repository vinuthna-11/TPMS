// src/pages/Login.js

import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate, Link } from 'react-router-dom';
import '../components/login.css';

const API_URL = 'http://127.0.0.1:8000/api';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const payload = {
        username: username,
        password: password
      };

      const response = await axios.post(`${API_URL}/login/`, payload);

      if (response.data.token) {
        localStorage.setItem('authToken', response.data.token);
        navigate('/profile');
      }
    } catch (err) {
      if (err.response && err.response.data) {
        setError(err.response.data.error || 'Login failed. Please try again.');
      } else {
        setError('Login failed. Please check your connection.');
      }
      console.error('Login failed:', err);
    }
  };

  return (
    <>
      <div className="cont">
        <h1>Login</h1>
      </div>

      <div className="wrapper">
        <form className="loginpage" onSubmit={handleLogin}>
          <h2>Welcome Back!</h2>
          <p>Sign in to continue</p>
          <input 
            type='text' 
            placeholder='Username'
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <input 
            type='password' 
            placeholder='Password'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <p className="error-text">{error}</p>}
          {/* This is the line that was causing the error */}
          <div className="forgot-password-link">
              <Link to="/forgot-password">Forgot Password?</Link>
          </div>
          <button type="submit" className="login-btn">Login</button>
        </form>
      </div>
    </>
  );
}