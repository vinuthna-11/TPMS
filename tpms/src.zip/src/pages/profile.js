// src/pages/Profile.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';

const API_URL = 'http://127.0.0.1:8000/api';

const Profile = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const [userData, setUserData] = useState(location.state?.userData || null);
    const [loading, setLoading] = useState(!location.state?.userData);

    useEffect(() => {
        const fetchUserProfile = async () => {
            const token = localStorage.getItem('authToken');
            if (!token) {
                navigate('/login');
                return;
            }
            try {
                const response = await axios.get(`${API_URL}/profile/`, {
                    headers: { 'Authorization': `Token ${token}` }
                });
                setUserData(response.data);
            } catch (error) {
                console.error('Failed to fetch user profile:', error);
                navigate('/login');
            } finally {
                setLoading(false);
            }
        };

        if (!userData) {
            fetchUserProfile();
        }
    }, [userData, navigate]);

    // ---> NEW: Function to handle logout
    const handleLogout = async () => {
        const token = localStorage.getItem('authToken');
        try {
            // Tell the backend to invalidate the token
            await axios.post(`${API_URL}/logout/`, {}, {
                headers: { 'Authorization': `Token ${token}` }
            });
        } catch (error) {
            console.error('Logout failed:', error);
        } finally {
            // Always remove the token from the browser and redirect
            localStorage.removeItem('authToken');
            navigate('/login');
        }
    };

    if (loading) {
        return <div>Loading your profile...</div>;
    }

    if (!userData) {
        return <div>Could not load user data.</div>;
    }

    return (
        <div className="profile-page">
            <h1>Welcome, {userData.first_name}!</h1>
            <div className="profile-details">
                <h2>Your Details</h2>
                <p><strong>Username:</strong> {userData.username}</p>
                <p><strong>Email:</strong> {userData.email}</p>
                <p><strong>Full Name:</strong> {userData.first_name} {userData.last_name}</p>
                <p><strong>Role:</strong> {userData.profile?.role}</p>
                <p><strong>Phone Number:</strong> {userData.profile?.phone_number}</p>
                <p><strong>Address:</strong> {userData.profile?.address}</p>
                <p><strong>Date of Birth:</strong> {userData.profile?.dob}</p>
                <p><strong>Gender:</strong> {userData.profile?.gender}</p>
                
                {/* ---> NEW: Logout button <--- */}
                <button onClick={handleLogout} className="btn-secondary">Logout</button>
            </div>
        </div>
    );
};

export default Profile;